I am making personal edit to this translator:
github.com/WileytheBANG/pokeking-translator 

link to my GitHub with all the files:
https://github.com/compscimmo/pokeking-translator.git
https://github.com/compscimmo/pokeking.git

I copy and pasted the broswer-polyfill.min.js from here into my own file:
https://gist.github.com/sriharrsha/3b8fe6a989e55f21d31824c7f31be61f 

Installation & Usage Guide

✅ Install the Extension 

Firefox: open the xpi with firefox

Edge/Chrome:
Download or clone this repository to your computer.

Open your browser and go to:

Chrome: chrome://extensions/

Edge: edge://extensions/

Enable "Developer Mode" (toggle at the top right).

Click "Load unpacked", then select the project folder you downloaded.

Your extension is now installed!

🔄 Update the Dictionary
To update the internal translation dictionary:

Replace the dict.json file inside the extension folder with the new version.

Go back to the extensions page (chrome://extensions/ or edge://extensions/).

Click "Reload" under the Pokeking Translator extension.

💡 Usage Tips
Pin the extension to your browser toolbar for quick access.

After the page is fully loaded, click the Pokeking Translator icon to activate the translation.

Some Chinese text may remain in the output — this is non-essential and generally safe to ignore unless you stray from the intended solve.
